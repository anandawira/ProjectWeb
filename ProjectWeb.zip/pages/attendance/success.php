<body>
    <div class="container mt-4 text-center">
        <h1 class="display-1"><i class="fas fa-check-circle text-success"></i></h1>
        <h2 class="font-weight-normal">Your attendance has been recorded.</h2>
        <button type="button" onclick="logout()" class="btn btn-danger mt-4">Log Out</button>
    </div>
</body>
</html>